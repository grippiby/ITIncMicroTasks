import React, { useState } from 'react'
import { FullInput } from './FullInput/FullInput'
import { Index } from './InputAndButton/Index'

interface MicrotasksProps {}

export const Microtasks: React.FC<MicrotasksProps> = (props) => {
	const [message, setMessage] = useState<{ message: string }[]>([
		{ message: 'message1' },
		{ message: 'message2' },
		{ message: 'message3' },
		{ message: 'message4' },
		{ message: 'message5' },
	])
	const updateMessage = (title: string) => {
		setMessage([{ message: title }, ...message])
	}
	return (
		<div className="App">
			{/*<FullInput
				updateMessage={updateMessage}
				setMessage={setMessage}
				message={message}
			/>*/}
			<Index updateMessage={updateMessage} />
			{message.map((el, index) => {
				return <div key={index}>{el.message}</div>
			})}
		</div>
	)
}
