import React, { ChangeEvent, useState } from 'react'

interface InputProps {
	message: { message: string }[]
	setMessage: any
	updateMessage: (title: string) => void
}

export const FullInput: React.FC<InputProps> = (props) => {
	const [title, setTitle] = useState('')
	const onChangeInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
		setTitle(event.currentTarget.value)
	}
	const onClickButtonHandler = () => {
		props.updateMessage(title)
		setTitle('')
	}
	return (
		<div>
			<div>
				<input onChange={onChangeInputHandler} value={title} />
				<button onClick={onClickButtonHandler}>+</button>
				<div>{title}</div>
			</div>
		</div>
	)
}
