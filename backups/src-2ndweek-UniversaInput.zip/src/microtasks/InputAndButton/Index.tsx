import React, { useState } from 'react'
import s from './styles/index.module.css'
import { Button } from './Button'
import { Input } from './Input'

interface IndexProps {
	updateMessage: (title: string) => void
}

export const Index: React.FC<IndexProps> = (props) => {
	const [title, setTitle] = useState('')
	const addMessage = () => {
		props.updateMessage(title)
		setTitle('')
	}
	return (
		<div>
			{' '}
			<Input title={title} setTitle={setTitle} />
			<Button name={'Added'} callBack={addMessage} />
		</div>
	)
}
