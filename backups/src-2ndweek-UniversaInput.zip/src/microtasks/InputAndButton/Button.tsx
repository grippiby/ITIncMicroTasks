import React from 'react'

interface ButtonProps {
	name: string
	callBack: () => void
}

export const Button: React.FC<ButtonProps> = (props) => {
	const onClickButtonHandler = () => {
		props.callBack()
	}
	return (
		<div>
			<button onClick={onClickButtonHandler}>{props.name}</button>
		</div>
	)
}
