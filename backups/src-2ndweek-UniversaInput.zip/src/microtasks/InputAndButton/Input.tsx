import React, { ChangeEvent } from 'react'
import s from './styles/Input.module.css'
import { Buffer } from 'buffer'
import { Button } from './Button'

interface InputProps {
	title: string
	setTitle: (title: string) => void
}

export const Input: React.FC<InputProps> = (props) => {
	const onChangeInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
		props.setTitle(event.currentTarget.value)
	}
	return (
		<div>
			<input onChange={onChangeInputHandler} value={props.title} />
			<div>Опа! Текст: {props.title}</div>
		</div>
	)
}
