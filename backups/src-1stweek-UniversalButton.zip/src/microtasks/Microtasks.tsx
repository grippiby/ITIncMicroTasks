import React from 'react'
import Week1 from './Monday/Week 1/Week1'

export const Microtasks = () => {
	return (
		<div>
			<Week1 />
		</div>
	)
}
