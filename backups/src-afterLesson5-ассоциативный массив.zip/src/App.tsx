import React, { useState } from 'react'
import './App.css'
import { TaskType, Todolist } from './Todolist'
import { v1 } from 'uuid'

export type FilterValuesType = 'all' | 'active' | 'completed'
export type TodolistsType = {
	id: string
	title: string
	filter: FilterValuesType
}
type TaskStateType = {
	[key: string]: TaskType[]
}
function App() {
	/*
	let [tasks, setTasks] = useState([
		{ id: v1(), title: 'HTML&CSS', isDone: true },
		{ id: v1(), title: 'JS', isDone: true },
		{ id: v1(), title: 'ReactJS', isDone: false },
		{ id: v1(), title: 'Rest API', isDone: false },
		{ id: v1(), title: 'GraphQL', isDone: false },
	])*/

	let todolistID1 = v1()
	let todolistID2 = v1()

	let [todolists, setTodolists] = useState<Array<TodolistsType>>([
		{ id: todolistID1, title: 'What to learn', filter: 'all' },
		{ id: todolistID2, title: 'What to buy', filter: 'all' },
	])

	let [tasks, setTasks] = useState<TaskStateType>({
		[todolistID1]: [
			{ id: v1(), title: 'HTML&CSS', isDone: true },
			{ id: v1(), title: 'JS', isDone: true },
			{ id: v1(), title: 'ReactJS', isDone: false },
		],
		[todolistID2]: [
			{ id: v1(), title: 'Rest API', isDone: true },
			{ id: v1(), title: 'GraphQL', isDone: false },
		],
	})
	function removeTodoList(id: string) {
		setTodolists(todolists.filter((el) => el.id !== id))
		delete tasks[id]
		setTasks({ ...tasks })
	}
	function removeTask(todoListId: string, id: string) {
		let myTasks = tasks[todoListId]
		tasks[todoListId] = myTasks.filter((t) => t.id !== id)
		setTasks({ ...tasks })
	}

	function addTask(todoListId: string, title: string) {
		let task = { id: v1(), title: title, isDone: false }
		let myTasks = tasks[todoListId]
		tasks[todoListId] = [task, ...myTasks]
		setTasks({ ...tasks })
	}

	function changeStatus(todoListId: string, taskId: string, isDone: boolean) {
		let myStatus = tasks[todoListId]
		let task = myStatus.find((t) => t.id === taskId)
		if (task) {
			task.isDone = isDone
			setTasks({ ...tasks })
		}
	}

	function changeFilter(todoListId: string, value: FilterValuesType) {
		let todoList = todolists.find((el) => el.id === todoListId)
		if (todoList) {
			todoList.filter = value
			setTodolists([...todolists])
		}
	}

	return (
		<div className="App">
			{todolists.map((el) => {
				let tasksForTodolist = tasks[el.id]

				if (el.filter === 'active') {
					tasksForTodolist = tasks[el.id].filter(
						(t) => t.isDone === false
					)
				}
				if (el.filter === 'completed') {
					tasksForTodolist = tasks[el.id].filter(
						(t) => t.isDone === true
					)
				}

				return (
					<Todolist
						key={el.id}
						todoListId={el.id}
						removeTodoList={removeTodoList}
						title={el.title}
						tasks={tasksForTodolist}
						removeTask={removeTask}
						changeFilter={changeFilter}
						addTask={addTask}
						changeTaskStatus={changeStatus}
						filter={el.filter}
					/>
				)
			})}

			{/*<Todolist
				title="What to learn"
				tasks={tasksForTodolist}
				removeTask={removeTask}
				changeFilter={changeFilter}
				addTask={addTask}
				changeTaskStatus={changeStatus}
				filter={filter}
			/>*/}
		</div>
	)
}

export default App
