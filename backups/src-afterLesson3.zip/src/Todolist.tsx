import React, {
	ChangeEvent,
	ChangeEventHandler,
	KeyboardEvent,
	useState,
} from 'react'
import { FilterValuesType } from './App'

type TaskType = {
	id: string
	title: string
	isDone: boolean
}

type PropsType = {
	title: string
	tasks: Array<TaskType>
	removeTask: (taskId: string) => void
	changeFilter: (value: FilterValuesType) => void
	addTask: (inputText: string) => void
}

export function Todolist(props: PropsType) {
	const [inputText, setInputText] = useState('')

	const addTaskHandler = () => {
		props.addTask(inputText)
		setInputText('')
	}
	const onChangeInputHandler = (event: ChangeEvent<HTMLInputElement>) =>
		setInputText(event.currentTarget.value)
	const onKeyDownHandler = (event: KeyboardEvent<HTMLInputElement>) => {
		console.log(event.key)
		if (event.ctrlKey && event.key === 'Enter') {
			addTaskHandler()
		}
	}
	const onClickChangeAllFilterHandler = () => {
		props.changeFilter('all')
	}
	const onClickChangeActiveFilterHandler = () => {
		props.changeFilter('active')
	}
	const onClickChangeCompletedFilterHandler = () => {
		props.changeFilter('completed')
	}

	return (
		<div>
			<h3>{props.title}</h3>
			<div>
				<input
					value={inputText}
					onChange={onChangeInputHandler}
					onKeyDown={onKeyDownHandler}
				/>
				<button onClick={addTaskHandler}>+</button>
			</div>
			<ul>
				{props.tasks.map((t) => (
					<li key={t.id}>
						<input type="checkbox" checked={t.isDone} />
						<span>{t.title}</span>
						<button
							onClick={() => {
								props.removeTask(t.id)
							}}
						>
							x
						</button>
					</li>
				))}
			</ul>
			<div>
				<button onClick={onClickChangeAllFilterHandler}>All</button>
				<button onClick={onClickChangeActiveFilterHandler}>
					Active
				</button>
				<button onClick={onClickChangeCompletedFilterHandler}>
					Completed
				</button>
			</div>
		</div>
	)
}
